public class EmployeeFulltime {

}
