package com.example.lab3_ex1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;
import android.widget.ArrayAdapter;
import android.view.View;
import android.widget.AdapterView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView listView = (ListView) findViewById(R.id.listView);
        DatabaseHandler db = new DatabaseHandler(this);
/**
 * CRUD Operations
 * */
// Inserting Contacts
        db.addContact(new Contact("Cuong", "0829004003"));
// Reading all contacts
        List<Contact> contacts = db.getAllContacts();
        ArrayList<String> contactNames = new ArrayList<String>();
        for (Contact cn : contacts) {
//            Add to list view
            String log = "Id: " + cn.getID() + " ,Name: " + cn.getName() + " ,Phone: " + cn.getPhoneNumber();
            contactNames.add(log);
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, contactNames);
        listView.setAdapter(adapter);
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the contact to be deleted
                Contact contact = contacts.get(position);

                // Delete the contact from the database
                db.deleteContact(contact);

                // Remove the contact from the contacts list
                contactNames.remove(position);

                // Update the ListView
                adapter.notifyDataSetChanged();

                return true;
            }
        });
    }

}