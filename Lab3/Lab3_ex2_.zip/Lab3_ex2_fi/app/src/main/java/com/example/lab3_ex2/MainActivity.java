package com.example.lab3_ex2;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import android.app.Dialog;
import android.widget.Button;
import android.widget.EditText;
import android.widget.DatePicker;
import android.app.DatePickerDialog;
import java.util.Calendar;
import android.widget.Toast;
import android.content.Intent;
public class MainActivity extends AppCompatActivity implements  StudentAdapter.OnStudentListener{
    private List<Student> students = new ArrayList<Student>();
//    private ArrayList<String> studentNames = new ArrayList<String>();
    private StudentAdapter adapter;

    private DatabaseHandler db = new DatabaseHandler(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");


//        students = db.getAllContacts();
//        for (Student cn : students) {
//            String log = "Id: " + cn.getID() + " ,Name: " + cn.getName() ;
//            String test = " ,Phone: " + cn.getPhoneNumber() + " ,Email: " + cn.getEmail() + " ,Address: " + cn.getAddress() + " ,Class: " + cn.getClassName() + " ,Birthday: " + sdf.format(cn.getBirthday());
//            Log.d("Name: ", log + test);
//            studentNames.add(log);
//        }
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new StudentAdapter(students, this);;
        recyclerView.setAdapter(adapter);
        // MainActivity.java
        Button btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create a new dialog
                Dialog dialog = new Dialog(MainActivity.this);
                dialog.setContentView(R.layout.dialog_add_student);

                // Find the EditText in the dialog
                EditText edtBirthday = dialog.findViewById(R.id.edtBirthday);
                edtBirthday.setFocusable(false);
                edtBirthday.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Get current date
                        final Calendar c = Calendar.getInstance();
                        int mYear = c.get(Calendar.YEAR);
                        int mMonth = c.get(Calendar.MONTH);
                        int mDay = c.get(Calendar.DAY_OF_MONTH);

                        // Launch Date Picker Dialog
                        DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this,
                                new DatePickerDialog.OnDateSetListener() {
                                    @Override
                                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                        // Display Selected date in EditText
                                        edtBirthday.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                                    }
                                }, mYear, mMonth, mDay);
                        datePickerDialog.show();
                    }
                });

                // Find the button in the dialog
                Button btnAddStudent = dialog.findViewById(R.id.btnAddStudent);
                btnAddStudent.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Handle the add student logic here
                        EditText edtName = dialog.findViewById(R.id.edtName);
                        EditText edtPhoneNumber = dialog.findViewById(R.id.edtPhone);
                        EditText edtEmail = dialog.findViewById(R.id.edtEmail);
                        EditText edtAddress = dialog.findViewById(R.id.edtAddress);
                        EditText edtClassName = dialog.findViewById(R.id.edtClass);
                        EditText edtBirthday = dialog.findViewById(R.id.edtBirthday);
                        try{
                            Date date = sdf.parse(edtBirthday.getText().toString());
                            Student student = new Student(edtName.getText().toString(), edtPhoneNumber.getText().toString(), edtEmail.getText().toString(), edtAddress.getText().toString(), edtClassName.getText().toString(), date);
                            int id = db.addStudent(student);
                            student.setID(id);

                            adapter.addStudent(student);
                            adapter.notifyDataSetChanged();
                        }catch (Exception e){
                            Toast.makeText(MainActivity.this, "Invalid date format", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        // Dismiss the dialog
                        dialog.dismiss();
                    }
                });

                // Show the dialog
                dialog.show();
            }
        });



    }
    @Override
    protected void onResume() {
        super.onResume();

        // Clear the previous student list
        students.clear();

        // Get the updated student list from the database
        students.addAll(db.getAllContacts());

        // Notify the adapter about the changes
        adapter.notifyDataSetChanged(); // Call notifyDataSetChanged on the StudentAdapter instance
    }

    @Override
    public void onStudentClick(int position) {
        Student selectedStudent = students.get(position);
        Intent intent = new Intent(MainActivity.this, ViewStudentActivity.class);
        intent.putExtra("ID", selectedStudent.getID());
        intent.putExtra("Name", selectedStudent.getName());
        intent.putExtra("PhoneNumber", selectedStudent.getPhoneNumber());
        intent.putExtra("Email", selectedStudent.getEmail());
        intent.putExtra("Address", selectedStudent.getAddress());
        intent.putExtra("ClassName", selectedStudent.getClassName());
        intent.putExtra("Birthday", selectedStudent.getBirthday().getTime());
        startActivity(intent);
    }
    @Override
    public boolean onStudentLongClick(int position) {
        // Get the student to be deleted
        Student student = students.get(position);

        // Delete the student from the database
        db.deleteStudent(student);

        // Remove the student from the students list
        students.remove(position);

        // Notify the adapter about the changes
        adapter.notifyDataSetChanged();

        return true;
    }
}