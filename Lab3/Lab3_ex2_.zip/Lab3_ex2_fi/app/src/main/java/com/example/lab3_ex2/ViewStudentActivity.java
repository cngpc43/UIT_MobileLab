package com.example.lab3_ex2;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.widget.Button;
import android.view.View;
import java.text.ParseException;
import com.example.lab3_ex2.R;

public class ViewStudentActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_student);

        // Get the Intent that started this activity
        Intent intent = getIntent();

        // Retrieve the student's information
        int id = intent.getIntExtra("ID", 0);
        String name = intent.getStringExtra("Name");
        String phoneNumber = intent.getStringExtra("PhoneNumber");
        String email = intent.getStringExtra("Email");
        String address = intent.getStringExtra("Address");
        String className = intent.getStringExtra("ClassName");
        Date birthday = new Date(intent.getLongExtra("Birthday", 0)); // Convert the time in milliseconds to a Date

        // Display the student's information
        ((TextView) findViewById(R.id.tvIDValue)).setText(String.valueOf(id));
        ((TextView) findViewById(R.id.tvNameValue)).setText(name);
        ((TextView) findViewById(R.id.tvPhoneValue)).setText(phoneNumber);
        ((TextView) findViewById(R.id.tvEmailValue)).setText(email);
        ((TextView) findViewById(R.id.tvAddressValue)).setText(address);
        ((TextView) findViewById(R.id.tvClassValue)).setText(className);
        ((TextView) findViewById(R.id.tvBirthdayValue)).setText(new SimpleDateFormat("dd/MM/yyyy").format(birthday));
        Button btnBack = (Button) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        Button btnEdit = findViewById(R.id.btnSave);
        btnEdit.setEnabled(false); // Initially disable the button
        // Get references to the EditText fields
        EditText tvNameValue = findViewById(R.id.tvNameValue);
        EditText tvPhoneValue = findViewById(R.id.tvPhoneValue);
        EditText tvEmailValue = findViewById(R.id.tvEmailValue);
        EditText tvAddressValue = findViewById(R.id.tvAddressValue);
        EditText tvClassValue = findViewById(R.id.tvClassValue);
        EditText tvBirthdayValue = findViewById(R.id.tvBirthdayValue);
        // Create a TextWatcher
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Enable the button when text is changed
                btnEdit.setEnabled(true);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        };

        // Add the TextWatcher to the EditText fields
        tvNameValue.addTextChangedListener(textWatcher);
        tvPhoneValue.addTextChangedListener(textWatcher);
        tvEmailValue.addTextChangedListener(textWatcher);
        tvAddressValue.addTextChangedListener(textWatcher);
        tvClassValue.addTextChangedListener(textWatcher);
        tvBirthdayValue.addTextChangedListener(textWatcher);

        Button btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the updated information
                String updatedName = tvNameValue.getText().toString();
                String updatedPhoneNumber = tvPhoneValue.getText().toString();
                String updatedEmail = tvEmailValue.getText().toString();
                String updatedAddress = tvAddressValue.getText().toString();
                String updatedClassName = tvClassValue.getText().toString();
                String updatedBirthday = tvBirthdayValue.getText().toString();

                // Parse the updatedBirthday string to a Date object
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                Date date = null;
                try {
                    date = sdf.parse(updatedBirthday);
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                // Create a new Student object with the updated information
                Student updatedStudent = new Student(updatedName, updatedPhoneNumber, updatedEmail, updatedAddress, updatedClassName, date);
                updatedStudent.setID(id); // Set the ID of the student to be updated

                // Create a DatabaseHandler object
                DatabaseHandler db = new DatabaseHandler(ViewStudentActivity.this);

                // Update the student's information in the database
                db.updateStudent(updatedStudent);
                // Update the student's information in the TextViews
                ((TextView) findViewById(R.id.tvNameValue)).setText(updatedName);
                ((TextView) findViewById(R.id.tvPhoneValue)).setText(updatedPhoneNumber);
                ((TextView) findViewById(R.id.tvEmailValue)).setText(updatedEmail);
                ((TextView) findViewById(R.id.tvAddressValue)).setText(updatedAddress);
                ((TextView) findViewById(R.id.tvClassValue)).setText(updatedClassName);
                ((TextView) findViewById(R.id.tvBirthdayValue)).setText(updatedBirthday);

                // Disable the button
                btnEdit.setEnabled(false);
            }
        });
    }

}
