package com.example.lab3_ex2;
import java.util.Date;
public class Student {
    public Student(String name, String phoneNumber, String email, String address, String class_name, Date birthday) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.address = address;
        this.class_name = class_name;
        this.birthday = birthday;
    }
    private int id;
    private String name;
    private Date birthday;
    private String phoneNumber;
    private String email;
    private String address;
    private String class_name;
    //….
    public int getID(){
        return this.id;
    }
    public void setID(int id){
        this.id = id;
    }
    public String getName(){
        return this.name;
    }
    public String getEmail(){
        return this.email;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public String  getAddress(){
        return this.address;
    }
    public void setAddress(String address){
        this.address = address;
    }
    public String getClassName(){
        return this.class_name;
    }
    public void setClassName(String class_name){
        this.class_name = class_name;
    }
    public Date getBirthday(){
        return this.birthday;
    }
    public void setBirthday(Date birthday){
        this.birthday = birthday;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getPhoneNumber(){
        return this.phoneNumber;
    }
    public void setPhoneNumber(String phone_number){
        this.phoneNumber = phone_number;
    }
}
