package com.example.lab3_ex2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.ViewHolder> {
    private List<Student> students;
    private OnStudentListener onStudentListener;
    public interface OnStudentListener {
        void onStudentClick(int position);
        boolean onStudentLongClick(int position);
    }
    public StudentAdapter(List<Student> students, OnStudentListener onStudentListener) {
        this.students = students;
        this.onStudentListener = onStudentListener;
    }
    public void addStudent(Student student) {
        this.students.add(student);
        notifyItemInserted(students.size() - 1);
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.student_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Student student = students.get(position);
        holder.tvStudentName.setText("Id: " + student.getID() + " ,Name: " + student.getName());
    }

    @Override
    public int getItemCount() {
        return students.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener {
        TextView tvStudentName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvStudentName = itemView.findViewById(R.id.tvStudentName);
            itemView.setOnClickListener(this);
            itemView.setOnLongClickListener(this);
        }
        @Override
        public void onClick(View v) {
            onStudentListener.onStudentClick(getAdapterPosition());
        }

        @Override
        public boolean onLongClick(View v) {
            return onStudentListener.onStudentLongClick(getAdapterPosition());
        }
    }
}